let cart = [];

function addToCart(product, price) {
    cart.push({ product, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerText = `${item.product} - ₹${item.price}`;
        cartList.appendChild(li);
    });
}

function filterProducts() {
    const searchValue = document.getElementById("search").value.toLowerCase();
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        const name = product.querySelector("h2").innerText.toLowerCase();
        product.style.display = name.includes(searchValue) ? "block" : "none";
    });
}
let cart = [];

function addToCart(product, price) {
    cart.push({ product, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>${item.product} - ₹${item.price}</strong>`;
        cartList.appendChild(li);
    });
}

document.getElementById("search").addEventListener("keyup", function () {
    const searchValue = this.value.toLowerCase();
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        const name = product.querySelector("h2").innerText.toLowerCase();
        product.style.display = name.includes(searchValue) ? "block" : "none";
    });
});
let cart = [];

function addToCart(product, price) {
    cart.push({ product, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>${item.product} - ₹${item.price}</strong>`;
        cartList.appendChild(li);
    });
}

function filterProducts() {
    const searchValue = document.getElementById("search").value.toLowerCase();
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        const name = product.querySelector("h2").innerText.toLowerCase();
        product.style.display = name.includes(searchValue) ? "block" : "none";
    });
}

function filterCategory(category) {
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        product.style.display = product.getAttribute("data-category") === category ? "block" : "none";
    });
}
let cart = [];

function addToCart(product, price) {
    cart.push({ product, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>${item.product} - ₹${item.price}</strong>`;
        cartList.appendChild(li);
    });
}

function filterProducts() {
    const searchValue = document.getElementById("search").value.toLowerCase();
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        const name = product.querySelector("h2").innerText.toLowerCase();
        product.style.display = name.includes(searchValue) ? "block" : "none";
    });
}

function filterCategory(category) {
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        product.style.display = product.getAttribute("data-category") === category ? "block" : "none";
    });
}
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    function checkout() {
        let totalAmount = cart.reduce((sum, item) => sum + item.price, 0);
        if (totalAmount === 0) {
            alert("Your cart is empty!");
            return;
        }

        let options = {
            key: "rzp_test_YourKeyHere", // Replace with your Razorpay Test/Live Key
            amount: totalAmount * 100, // Convert to paise
            currency: "INR",
            name: "Stunny",
            description: "Order Payment",
            image: "https://your-logo-url.com/logo.png", // Replace with your logo URL
            handler: function (response) {
                alert("Payment Successful! Payment ID: " + response.razorpay_payment_id);
                cart = [];
                updateCart();
            },
            prefill: {
                name: "User Name",
                email: "user@example.com",
                contact: "9999999999",
            },
            theme: {
                color: "#daa520",
            }
        };

        let rzp = new Razorpay(options);
        rzp.open();
    }
</script>
const categories = [
    "Makeup", "Skin", "Haircare", "Appliance", "Bath & Body", 
    "Naturals", "Mom & Baby", "Health & Wellness", "Men", 
    "Fragrance", "Lingerie & Accessories"
];

const categoryList = document.getElementById("categoryList");
categories.forEach(category => {
    let div = document.createElement("div");
    div.classList.add("category");
    div.innerText = category;
    div.onclick = () => filterCategory(category.toLowerCase());
    categoryList.appendChild(div);
});

// Dummy products (Replace this with actual CSV data)
const products = [
    { name: "Lipstick", price: 299, category: "makeup", image: "lipstick.jpg" },
    { name: "Foundation", price: 599, category: "makeup", image: "foundation.jpg" }
];

function loadProducts() {
    const productContainer = document.getElementById("products");
    productContainer.innerHTML = "";
    products.forEach(product => {
        let div = document.createElement("div");
        div.classList.add("product");
        div.setAttribute("data-category", product.category);
        div.innerHTML = `
            <img src="${product.image}" alt="${product.name}" width="100">
            <h2>${product.name}</h2>
            <p><strong>₹${product.price}</strong></p>
            <button class="button" onclick="addToCart('${product.name}', ${product.price})">ADD TO CART</button>
        `;
        productContainer.appendChild(div);
    });
}

let cart = [];

function addToCart(product, price) {
    cart.push({ product, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart");
    cartList.innerHTML = "";
    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>${item.product} - ₹${item.price}</strong>`;
        cartList.appendChild(li);
    });
}

function filterProducts() {
    const searchValue = document.getElementById("search").value.toLowerCase();
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        const name = product.querySelector("h2").innerText.toLowerCase();
        product.style.display = name.includes(searchValue) ? "block" : "none";
    });
}

function filterCategory(category) {
    const products = document.querySelectorAll(".product");
    products.forEach(product => {
        if (product.getAttribute("data-category") === category || category === "all") {
            product.style.display = "block";
        } else {
            product.style.display = "none";
        }
    });
}

function checkout() {
    let totalAmount = cart.reduce((sum, item) => sum + item.price, 0);
    if (totalAmount === 0) {
        alert("Your cart is empty!");
        return;
    }

    let options = {
        key: "rzp_test_YourKeyHere", // Replace with your Razorpay API Key
        amount: totalAmount * 100,
        currency: "INR",
        name: "Stunny",
        description: "Order Payment",
        image: "https://your-logo-url.com/logo.png",
        handler: function (response) {
            alert("Payment Successful! Payment ID: " + response.razorpay_payment_id);
            cart = [];
            updateCart();
        },
        prefill: {
            name: "User Name",
            email: "user@example.com",
            contact: "9999999999",
        },
        theme: {
            color: "#daa520",
        }
    };

    let rzp = new Razorpay(options);
    rzp.open();
}

// Load products on page load
window.onload = loadProducts;
async function loadProducts() {
    try {
        let response = await fetch("products.json"); // Fetch product data
        let products = await response.json();
        let productContainer = document.getElementById("products");
        productContainer.innerHTML = "";

        products.forEach(product => {
            let div = document.createElement("div");
            div.className = "product";
            div.setAttribute("data-category", product.category.toLowerCase());

            div.innerHTML = `
                <h3>${product.name}</h3>
                <p>₹${product.price}</p>
                <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
            `;

            productContainer.appendChild(div);
        });
    } catch (error) {
        console.error("Error loading products:", error);
    }
}

let cart = [];

function addToCart(name, price) {
    cart.push({ name, price });
    updateCart();
}

function updateCart() {
    let cartList = document.getElementById("cart");
    cartList.innerHTML = cart.map(item => `<li>${item.name} - ₹${item.price}</li>`).join("");
}

function filterProducts() {
    let searchValue = document.getElementById("search").value.toLowerCase();
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.innerText.toLowerCase().includes(searchValue) ? "block" : "none";
    });
}

function filterCategory(category) {
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.getAttribute("data-category") === category ? "block" : "none";
    });
}

window.onload = loadProducts;
// Load products from JSON and display them
async function loadProducts() {
    try {
        let response = await fetch("products.json"); // Load JSON file
        let products = await response.json();
        let productContainer = document.getElementById("products");

        productContainer.innerHTML = ""; // Clear previous products

        products.forEach(product => {
            productContainer.innerHTML += `
                <div class="product" data-category="${product.category.toLowerCase()}">
                    <h3>${product.name}</h3>
                    <p>₹${product.price}</p>
                    <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
                </div>
            `;
        });
    } catch (error) {
        console.error("Failed to load products:", error);
    }
}

// Add items to cart
let cart = [];
function addToCart(name, price) {
    cart.push({ name, price });
    updateCart();
}

// Update cart display
function updateCart() {
    let cartList = document.getElementById("cart");
    cartList.innerHTML = cart.map(item => `<li>${item.name} - ₹${item.price}</li>`).join("");
}

// Search products
function filterProducts() {
    let searchValue = document.getElementById("search").value.toLowerCase();
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.innerText.toLowerCase().includes(searchValue) ? "block" : "none";
    });
}

// Filter by category
function filterCategory(category) {
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.getAttribute("data-category") === category ? "block" : "none";
    });
}

// Load products when the page opens
window.onload = loadProducts;
// Load products from JSON and display them
async function loadProducts() {
    try {
        let response = await fetch("products.json"); // Fetch JSON file
        let products = await response.json();
        let productContainer = document.getElementById("products");

        productContainer.innerHTML = ""; // Clear previous products

        products.forEach(product => {
            productContainer.innerHTML += `
                <div class="product" data-category="${product.category?.toLowerCase()}">
                    <img src="${product.image_url}" alt="${product.name}" width="100">
                    <h3>${product.name}</h3>
                    <p>₹${product.price}</p>
                    <a href="${product.link}" target="_blank">View Product</a>
                    <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
                </div>
            `;
        });
    } catch (error) {
        console.error("Failed to load products:", error);
    }
}

// Add items to cart
let cart = [];
function addToCart(name, price) {
    cart.push({ name, price });
    updateCart();
}

// Update cart display
function updateCart() {
    let cartList = document.getElementById("cart");
    cartList.innerHTML = cart.map(item => `<li>${item.name} - ₹${item.price}</li>`).join("");
}

// Search products
function filterProducts() {
    let searchValue = document.getElementById("search").value.toLowerCase();
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.innerText.toLowerCase().includes(searchValue) ? "block" : "none";
    });
}

// Filter by category
function filterCategory(category) {
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.getAttribute("data-category") === category ? "block" : "none";
    });
}

// Load products when the page opens
window.onload = loadProducts;
document.addEventListener("DOMContentLoaded", function () {
    loadProducts();
});

// Load products from JSON and display them
async function loadProducts() {
    try {
        let response = await fetch("products.json"); // Ensure this file exists in your project
        let products = await response.json();
        let productContainer = document.getElementById("products");

        productContainer.innerHTML = ""; // Clear previous products

        products.forEach(product => {
            let productElement = document.createElement("div");
            productElement.classList.add("product");
            productElement.setAttribute("data-category", product.category ? product.category.toLowerCase() : "other");

            productElement.innerHTML = `
                <img src="${product.image_url}" alt="${product.name}" width="100">
                <h3>${product.name}</h3>
                <p>₹${product.price}</p>
                <a href="${product.link}" target="_blank">View Product</a>
                <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
            `;
            productContainer.appendChild(productElement);
        });
    } catch (error) {
        console.error("Error loading products:", error);
    }
}

// Cart functionality
let cart = [];

function addToCart(name, price) {
    cart.push({ name, price });
    updateCart();
}

function updateCart() {
    let cartList = document.getElementById("cart");
    cartList.innerHTML = cart.map(item => `<li>${item.name} - ₹${item.price}</li>`).join("");
}

// Search Function
document.getElementById("search").addEventListener("keyup", function () {
    let searchValue = this.value.toLowerCase();
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.innerText.toLowerCase().includes(searchValue) ? "block" : "none";
    });
});

// Category Filter
function filterCategory(category) {
    document.querySelectorAll(".product").forEach(product => {
        product.style.display = product.getAttribute("data-category") === category ? "block" : "none";
    });
}
[
    {
        "name": "Lakme Lipstick",
        "category": "makeup",
        "price": 399,
        "image_url": "https://example.com/lakme-lipstick.jpg",
        "link": "https://www.nykaa.com/lakme-lipstick"
    },
    {
        "name": "Nivea Body Lotion",
        "category": "bath-body",
        "price": 249,
        "image_url": "https://example.com/nivea-lotion.jpg",
        "link": "https://www.nykaa.com/nivea-body-lotion"
    },
    {
        "name": "Mamaearth Face Wash",
        "category": "skin",
        "price": 299,
        "image_url": "https://example.com/mamaearth-facewash.jpg",
        "link": "https://www.nykaa.com/mamaearth-facewash"
    }
]
fetch("https://gist.githubusercontent.com/your-username/raw/products.json")
fetch("https://your-hosted-url.com/products.json")  // Replace with the actual GitHub link
    .then(response => response.json())
    .then(data => displayProducts(data))
    .catch(error => console.error("Error fetching products:", error));
